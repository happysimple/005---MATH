%% ====================================================
% 使用BP神经网络建模_多变量（利用前7天数据滚动预测后1天数据）
%% ====================================================
clear;clc;

% 加载数据
load A 

% 划分训练数据与测试数据
scale = 0.8;
num = size(A,1);
num_train = fix(scale * num);
num_test = num-num_train;
mytrain = A(1:num_train,:)'; 
mytest = A(num_train+1:num_train+num_test,:)'; 

% 训练数据归一化
[mytrain_norm,ref1] = mapminmax(mytrain,0,1);
[~,ref2] = mapminmax(mytrain(2,:),0,1);

% 构造训练数据
for i=1:num_train-7
    x(:,i)=reshape(mytrain_norm(:,i:i+6),[],1);
    y(:,i)=mytrain_norm(2,i+7);
end

% 构建BP神经网络
net=feedforwardnet(24);

% 设置默认参数
net.trainParam.lr=0.001;     % 学习速率
net.trainParam.epochs=300;   % 最大训练次数
net.trainParam.showWindow=1; % 显示训练窗口
net.trainParam.show=25;      % 两次显示之间的训练步数
net.trainParam.goal=0.0001;  % 训练目标
net.trainParam.time=inf;     % 训练时间

% 训练网络
net=train(net,x,y);

% 测试数据归一化
mytest_norm=mapminmax('apply',mytest,ref1);

% 构造测试数据
for i=1:num_test-7
    u(:,i)=reshape(mytest_norm(:,i:i+6),[],1);
    v(:,i)=mytest_norm(2,i+7);
end

% 测试BP神经网络
v_pred = sim(net,u);

% 预测数据去归一化
v_pred = mapminmax('reverse',v_pred,ref2);
v = mapminmax('reverse',v,ref2);

% 计算rms
rms1 = rms(v_pred-v);
rms1 = sprintf('%.2f',rms1);

% 计算mean
mean1 = mean(v_pred-v);
mean1 = sprintf('%.2f',mean1);

% 绘图
figure;
hold on 
box on
plot(8:num_test,v,'LineWidth',1.2);
plot(8:num_test,v_pred,'LineWidth',1.2);
xlim([0,550]);
xlabel('Day');
ylabel('H (m)');
legend('True','Predict');
hold off
set(gca,'FontSize',12);
set(gcf,'Units','centimeters','Position',[8 5 15 8]);
exportgraphics(gcf,'002.png','Resolution',600);



