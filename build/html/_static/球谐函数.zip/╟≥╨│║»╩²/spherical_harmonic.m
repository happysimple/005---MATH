function B=spherical_harmonic(mylon,mylat)
    k=1;
    for n=0:15
        for m=0:n
            % 克罗内克函数
            if m==0
                flag=0;
            else
                flag=1;
            end
            % 归化函数
            mc=sqrt(factorial(n-m)*(2*n+1)*(2-flag)/factorial(n+m));
            % 经典勒让德函数
            lrd = legendre(n,sind(mylat),'unnorm');
            lrd =lrd(m+1,:)';
            % 归化勒让德函数
            Phat=mc*lrd;
            % 输出矩阵
            if m==0
                B(:,k)=Phat; k=k+1;
            else
                B(:,k)=cosd(m*mylon).*Phat; k=k+1;
                B(:,k)=sind(m*mylon).*Phat; k=k+1;
            end
        end
    end
end



