clear;clc;
% 加载原始数据
ncfile='00.nc';
lon=ncread(ncfile,'lon');
lat=ncread(ncfile,'lat');
TEC1=ncread(ncfile,'TEC');
TEC1=TEC1';

% 重构数据
mylon=(-180:5:180)';
mylon=repmat(mylon,[71,1]);
mylat=(87.5:-2.5:-87.5)';
mylat=reshape(repmat(mylat,[1,73])',[5183,1]);
L=reshape(TEC1',5183,1);

% 球谐函数解算
B=spherical_harmonic(mylon,mylat);
X=(B'*B)\(B'*L);
 
% 计算融合产品
 TEC2=zeros(71,73);
 for j=1:length(lat)
    for k=1:length(lon)
        B=spherical_harmonic(lon(k),lat(j));            
        TEC2(j,k)=B*X;
    end
 end
 
% 绘图
subplot(3,1,1);
pcolor(lon,lat,TEC1);
title('原始数据');
shading interp  
colormap(jet);
colorbar;

subplot(3,1,2);
pcolor(lon,lat,TEC2);
title('球谐函数生成的数据');
shading interp   
colormap(jet);
colorbar;

subplot(3,1,3);
pcolor(lon,lat,TEC2-TEC1);
title('差值');
shading interp   
colormap(jet);
colorbar;

exportgraphics(gcf,'001.png','Resolution',600);
